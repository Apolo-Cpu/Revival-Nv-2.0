﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using ExcelAutoFormat = Microsoft.Office.Interop.Excel.XlRangeAutoFormat;
using Microsoft.Office.Interop;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.IO.Ports;

namespace Revival_NV
{
    public partial class Form3 : Form
    {

        string StrParse, LDR_1, LDR_2, Pot;
        int LDR_1L, LDR_2L, PotL;
        int Limit = 10;
        string FilePathAndName;
        string recibido;
        private string strBufferIn;
        private string strBufferOut;

        public Form3()
        {
            InitializeComponent();
        }

        //----- Comunicacion Programa

        private delegate void DelegadoAcceso(string accion);

        private void AccesoForm(string accion) //Datos Recibidos
        {
            strBufferIn = accion;
            recibido = strBufferIn;
            textrecibido.Text = recibido;
            LabelLDR2.Text = recibido;

        }
        private void AccesoInterrupcion(string accion)
        {
            DelegadoAcceso Var_DelegadoAcceso = new DelegadoAcceso(AccesoForm);
            object[] arg = { accion };
            base.Invoke(Var_DelegadoAcceso, arg);
        }


        private void Form3_Load(object sender, EventArgs e) //Estado Inicial del Formulario
        {
            CenterToScreen();
            ButtonDisconnect.Enabled = false;
            ButtonConnect.Enabled = false;
            ButtonStartRecording.Enabled = false;
            ButtonStopRecording.Enabled = false;
            ComboBoxBaudRate.SelectedIndex = 3;
            ButtonSaveToExcel.Height = 50;
            int limit = 10;

            for (int i = 0; i <= 30; i++)  //arreglo para adquisicion de datos
            {
                Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), 0);
                if (Chart1.Series["LDR1"].Points.Count == limit)
                {
                    Chart1.Series["LDR1"].Points.RemoveAt(0);
                }

                Chart1.Series["LDR2"].Points.AddY(0);
                if (Chart1.Series["LDR2"].Points.Count == limit)
                {
                    Chart1.Series["LDR2"].Points.RemoveAt(0);
                }

                Chart1.Series["POTENTIO"].Points.AddY(0);
                if (Chart1.Series["POTENTIO"].Points.Count == limit)
                {
                    Chart1.Series["POTENTIO"].Points.RemoveAt(0);
                }
            }
        }

        private void ButtonScanPort_Click(object sender, EventArgs e)
        {
            ComboBoxPort.Items.Clear();
            string[] myPort = SerialPort.GetPortNames();

            foreach (string port in myPort)
            {
                ComboBoxPort.Items.Add(port);
            }

            if (ComboBoxPort.Items.Count > 0)
            {
                ComboBoxPort.SelectedIndex = 0;
                ButtonConnect.Enabled = true;
            }
            else
            {
                MessageBox.Show("Com port not detected", "Warning !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ComboBoxPort.Text = "";
                ComboBoxPort.Items.Clear();
                ButtonConnect.Enabled = false;
                ButtonStartRecording.Enabled = false;
            }

            ComboBoxPort.DroppedDown = true;
        }

        private void ButtonConnect_Click(object sender, EventArgs e) //Conectar
        {
            if (ButtonConnect.Text == "Conectar")
            {
            SerialPort1.BaudRate = int.Parse(ComboBoxBaudRate.SelectedItem.ToString());
            SerialPort1.PortName = ComboBoxPort.SelectedItem.ToString();
            SerialPort1.BaudRate = int.Parse(ComboBoxBaudRate.Text);
            SerialPort1.DataBits = 8;
            SerialPort1.Parity = Parity.None;
            SerialPort1.StopBits = StopBits.One;
            SerialPort1.Handshake = Handshake.None;
            SerialPort1.PortName = ComboBoxPort.Text;

            try
            {
                SerialPort1.Open();
                TimerSerial.Start();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un Fallo : " + ex.Message, "Error al conectar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
                ComboBoxPort.Enabled = false;
                Label1.Enabled = false;
                ComboBoxBaudRate.Enabled = false;
                ButtonScanPort.Enabled = false;
                ButtonConnect.Enabled = false;
                ButtonDisconnect.Enabled = true;
                ButtonStartRecording.Enabled = true;
                ButtonStopRecording.Enabled = false;

                PictureBoxConnectionInd.Image = Properties.Resources.Verde;
                LabelStatus.Text = "Estado : Conectado";
            }



        private void ButtonDisconnect_Click(object sender, EventArgs e) // Desconectar
        {
            if (SerialPort1.IsOpen)
            {
                SerialPort1.Close(); // Cierra el puerto serie si está abierto.
            }

            PictureBoxConnectionInd.Image = Properties.Resources.Rojo;
            PictureBoxConnectionInd.Visible = true;
            LabelStatus.Text = "Estado: Desconectado";

            ComboBoxPort.Enabled = true;
            Label1.Enabled = true;
            ComboBoxBaudRate.Enabled = true;
            ButtonScanPort.Enabled = true;
            ButtonConnect.Enabled = true;
            ButtonDisconnect.Enabled = false;

            TimerSerial.Stop();
            TimerDataLogRecord.Stop();

            ButtonSaveToExcel.Enabled = true;
            ButtonStopRecording.Enabled = false;
        }



        private void ButtonStartRecording_Click(object sender, EventArgs e)
        {
            ButtonStartRecording.Enabled = false;
            ButtonStopRecording.Enabled = true;
            ButtonSaveToExcel.Enabled = false;
            TimerDataLogRecord.Start();

            label2.Text = "Estado : Registrando";
            if (LDR_1 != null)
            {
                int startIndex = LDR_1.IndexOf("L1") + 2; // Encuentra la posición de "L1" y agrega 2 para omitirlo.
                if (startIndex >= 2 && startIndex < LDR_1.Length)
                {
                    string LDR1 = LDR_1.Substring(startIndex, LDR_1L - startIndex);
                    LabelLDR1.Text = "LDR1 = " + LDR1;
                }
                else
                {
                    // Manejar el caso en el que la cadena no tiene el formato esperado.
                    LabelLDR1.Text = "Formato de cadena incorrecto";
                }
            }
            else
            {
                // Manejar el caso en el que LDR_1 es null.
                LabelLDR1.Text = "No disponible";
            }


            //LabelLDR2.Text = "LDR2 = " + LDR_2.Substring(2, LDR_2L);
            //LabelPOT.Text = "POTENTIO = " + Pot.Substring(2, PotL);

        }

        private void botonenviar_Click(object sender, EventArgs e)
        {
            try
            {
                SerialPort1.DiscardOutBuffer();
                // strBufferOut = textenviar.Text; textbox con el nombre textenviar para visualizar y digitar valor enviado del tx rx
                strBufferOut = textenviado.Text;
                SerialPort1.Write(strBufferOut);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message.ToString());
            }
        }

        private void ButtonStopRecording_Click(object sender, EventArgs e) //Detener todo
        {
            ButtonStartRecording.Enabled = true;
            ButtonStopRecording.Enabled = false;
            ButtonSaveToExcel.Enabled = true;
            TimerDataLogRecord.Stop();
            PictureBoxRecordInd.Visible = true;

            LabelLDR1.Text = "Desconectado";
            label2.Text = "Estado : Detenido";
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 30; i++)
            {
                Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), 0);
                if (Chart1.Series["LDR1"].Points.Count == Limit)
                {
                    Chart1.Series["LDR1"].Points.RemoveAt(0);
                }
                Chart1.ChartAreas[0].AxisY.Maximum = 1100;

                Chart1.Series["LDR2"].Points.AddY(0);
                if (Chart1.Series["LDR2"].Points.Count == Limit)
                {
                    Chart1.Series["LDR2"].Points.RemoveAt(0);
                }

                Chart1.Series["POTENTIO"].Points.AddY(0);
                if (Chart1.Series["POTENTIO"].Points.Count == Limit)
                {
                    Chart1.Series["POTENTIO"].Points.RemoveAt(0);
                }
            }
            DataGridView1.Rows.Clear();
        }

        private void ButtonClear_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i <= 30; i++)
            {
                Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), 0);
                if (Chart1.Series["LDR1"].Points.Count == Limit)
                {
                    Chart1.Series["LDR1"].Points.RemoveAt(0);
                }
                Chart1.ChartAreas[0].AxisY.Maximum = 1100;

                Chart1.Series["LDR2"].Points.AddY(0);
                if (Chart1.Series["LDR2"].Points.Count == Limit)
                {
                    Chart1.Series["LDR2"].Points.RemoveAt(0);
                }

                Chart1.Series["POTENTIO"].Points.AddY(0);
                if (Chart1.Series["POTENTIO"].Points.Count == Limit)
                {
                    Chart1.Series["POTENTIO"].Points.RemoveAt(0);
                }
            }
            DataGridView1.Rows.Clear();
        }

        private void ButtonSaveToExcel_Click(object sender, EventArgs e) 
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();


            //---------------------------------------- Exportar a excel aun en proceso --------------------


            //    ButtonSaveToExcel.Height = 37;
            //    ButtonSaveToExcel.Text = "Please Wait...";
            //    ButtonSaveToExcel.Enabled = false;
            //    ButtonStartRecording.Enabled = false;
            //    ProgressBarProcess.Visible = true;
            //    ProgressBarProcess.Value = 1;

            //    Microsoft.Office.Interop.Excel.Application xlApp;
            //    Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            //    Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            //    object misValue = System.Reflection.Missing.Value;
            //    int i, j;

            //    ProgressBarProcess.Value = 3;

            //    try
            //    {
            //        xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Sheets["sheet1"];
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("Error al acceder a la hoja: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        // Realiza acciones para manejar el error, como cerrar el libro o salir de la aplicación.
            //    }


            //    xlApp = new Microsoft.Office.Interop.Excel.Application();
            //    xlWorkBook = xlApp.Workbooks.Add(misValue);
            //    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Sheets["sheet1"];

            //    ProgressBarProcess.Value = 5;

            //    for (i = 0; i < DataGridView1.RowCount - 1; i++)
            //    {
            //        for (j = 0; j < DataGridView1.ColumnCount; j++)
            //        {
            //            for (int k = 1; k <= DataGridView1.Columns.Count; k++)
            //            {
            //                xlWorkSheet.Cells[1, k] = DataGridView1.Columns[k - 1].HeaderText;
            //                xlWorkSheet.Cells[i + 2, j + 1] = DataGridView1[j, i].Value.ToString();
            //            }
            //        }
            //    }

            //    ProgressBarProcess.Value = 8;

            //    FilePathAndName = Application.StartupPath + "\\" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + ".xlsx";
            //    if (File.Exists(FilePathAndName)) File.Delete(FilePathAndName);

            //    xlWorkSheet.SaveAs(FilePathAndName);
            //    xlWorkBook.Close();
            //    xlApp.Quit();

            //    releaseObject(xlApp);
            //    releaseObject(xlWorkBook);
            //    releaseObject(xlWorkSheet);

            //    ProgressBarProcess.Value = 10;

            //    MessageBox.Show("Successfully saved" + Environment.NewLine + "File are saved at : " + FilePathAndName, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //    ProgressBarProcess.Visible = false;

            //   // Process.Start(FilePathAndName);

            //    ButtonSaveToExcel.Height = 50;
            //    ButtonSaveToExcel.Text = "Save To MS Excel";
            //    ButtonSaveToExcel.Enabled = true;
            //    ButtonStartRecording.Enabled = true;

            //private void releaseObject(object obj)
            //{
            //    try
            //    {
            //        System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            //        obj = null;
            //    }
            //    catch (Exception ex)
            //    {
            //        obj = null;
            //    }
            //    finally
            //    {
            //        GC.Collect();
            //    }
            //}
        }

        private void TimerDataLogRecord_Tick(object sender, EventArgs e)
        {
            string LDR_1Log, LDR_2Log, PotLog;
            DateTime DT = DateTime.Now;

            LDR_1Log = LDR_1.Substring(2, LDR_1L);
            LDR_2Log = LDR_2.Substring(2, LDR_2L);
            PotLog = Pot.Substring(2, PotL);

            DataGridView1.Rows.Add(new string[] { DataGridView1.RowCount.ToString(), LDR_1Log, LDR_2Log, PotLog, DT.ToLongTimeString(), DT.ToString("dd-MM-yyyy") });
            this.DataGridView1.FirstDisplayedScrollingRowIndex = this.DataGridView1.RowCount - 1;

            Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), double.Parse(LDR_1Log));
            if (Chart1.Series[0].Points.Count == Limit)
            {
                Chart1.Series[0].Points.RemoveAt(0);
            }

            Chart1.Series["LDR2"].Points.AddY(double.Parse(LDR_2Log));
            if (Chart1.Series[1].Points.Count == Limit)
            {
                Chart1.Series[1].Points.RemoveAt(0);
            }

            Chart1.Series["POTENTIO"].Points.AddY(double.Parse(PotLog));
            if (Chart1.Series[2].Points.Count == Limit)
            {
                Chart1.Series[2].Points.RemoveAt(0);
            }

            if (PictureBoxRecordInd.Visible == true)
            {
                PictureBoxRecordInd.Visible = false;
            }
            else if (PictureBoxRecordInd.Visible == false)
            {
                PictureBoxRecordInd.Visible = true;
            }
        }
        private void datorecibido(object sender, SerialDataReceivedEventArgs e)
        {
            AccesoInterrupcion(SerialPort1.ReadExisting());
        }

    }
}
