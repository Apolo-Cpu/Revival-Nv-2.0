﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using ExcelAutoFormat = Microsoft.Office.Interop.Excel.XlRangeAutoFormat;
using Microsoft.Office.Interop;
using System.IO;
using System.Xml.XPath;
using System.Xml;
using System.IO.Ports;

namespace Revival_NV
{
    public partial class Form3 : Form
    {
        private int Limit = 10;
        private string strBufferIn;
        private string strBufferOut;
        string recibido;

        private delegate void DelegadoAcceso(string accion);
        public Form3()
        {
            InitializeComponent();
        }
        private void AccesoForm(string accion)
        {
            strBufferIn = accion;
            //textrecibido.Text = strBufferIn;       textbox con el nombre texrecibido para visualizar valor recibido del tx rx
            recibido=strBufferIn;
            textrecibido.Text = recibido;

        }
        private void AccesoInterrupcion(string accion)
        {
            DelegadoAcceso Var_DelegadoAcceso;
            Var_DelegadoAcceso = new DelegadoAcceso(AccesoForm);
            object[] arg = { accion };
            base.Invoke(Var_DelegadoAcceso, arg);

        }
        private void Form3_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            ButtonDisconnect.Enabled = false;
            ButtonConnect.Enabled = false;
            ButtonStartRecording.Enabled = false;
            ButtonStopRecording.Enabled = false;
            ComboBoxBaudRate.SelectedIndex = 3;

            ButtonSaveToExcel.Height = 50;
            int Limit = 10;


            for (int i = 0; i <= 30; i++)
            {
                Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), 0);
                if (Chart1.Series["LDR1"].Points.Count == Limit)
                {
                    Chart1.Series["LDR1"].Points.RemoveAt(0);
                }
                Chart1.ChartAreas[0].AxisY.Maximum = 1100;

                Chart1.Series["LDR2"].Points.AddY(0);
                if (Chart1.Series["LDR2"].Points.Count == Limit)
                {
                    Chart1.Series["LDR2"].Points.RemoveAt(0);
                }

                Chart1.Series["POTENTIO"].Points.AddY(0);
                if (Chart1.Series["POTENTIO"].Points.Count == Limit)
                {
                    Chart1.Series["POTENTIO"].Points.RemoveAt(0);
                }
            }
        }

        private void ButtonScanPort_Click(object sender, EventArgs e)
        {
            ComboBoxPort.Items.Clear();
            string[] myPort = System.IO.Ports.SerialPort.GetPortNames();
            int i = 0;
            foreach (string port in myPort)
            {
                ComboBoxPort.Items.Add(port);
                i++;
            }

            if (i > 0)
            {
                ComboBoxPort.SelectedIndex = 0;
                ButtonConnect.Enabled = true;
            }
            else
            {
                MessageBox.Show("Com port not detected", "Warning !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ComboBoxPort.Text = "";
                ComboBoxPort.Items.Clear();
                ButtonConnect.Enabled = false;
                ButtonStartRecording.Enabled = false;
            }

            ComboBoxPort.DroppedDown = true;
        }

        private void ButtonConnect_Click(object sender, EventArgs e)     //24:31
        {
            if (ButtonConnect.Text == "Conectar")
            {

                serialPort1.BaudRate =int.Parse(ComboBoxBaudRate.Text);
                serialPort1.DataBits = 8;
                serialPort1.Parity = Parity.None;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Handshake = Handshake.None;
                serialPort1.PortName = ComboBoxPort.Text;
                
                try
                {
                    serialPort1.Open();
               
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message.ToString());
                }
            }

            ComboBoxPort.Enabled = false;
            label1.Enabled = false;
            ComboBoxBaudRate.Enabled = false;
            ButtonScanPort.Enabled = false;
            ButtonConnect.Enabled = false;
            ButtonDisconnect.Enabled = true;
            ButtonStartRecording.Enabled = true;

            PictureBoxConnectionInd.Image = Properties.Resources.Verde;
            LabelStatus.Text = "Status : Connected";
        }


        private void ButtonDisconnect_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            PictureBoxConnectionInd.Image = Properties.Resources.Rojo;
            PictureBoxConnectionInd.Visible = true;
            LabelStatus.Text = "Status : Disconnect";

            ComboBoxPort.Enabled = true;
            ComboBoxBaudRate.Enabled = true;
            ButtonScanPort.Enabled = true;
            ButtonConnect.Enabled = true;
            ButtonDisconnect.Enabled = false;


            ButtonSaveToExcel.Enabled = true;
            ButtonStopRecording.Enabled = false;
        }

        private void ButtonSaveToExcel_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
        }

        private void ButtonStartRecording_Click(object sender, EventArgs e)
        {
            ButtonStartRecording.Enabled = false;
            ButtonStopRecording.Enabled = true;
            ButtonSaveToExcel.Enabled = false;
            //TimerDataLogRecord.Start();
        }

        private void ButtonStopRecording_Click(object sender, EventArgs e)
        {
            ButtonStartRecording.Enabled = true;
            ButtonStopRecording.Enabled = false;
            ButtonSaveToExcel.Enabled = true;
            //TimerDataLogRecord.Stop();
            PictureBoxRecordInd.Visible = true;
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 30; i++)
            {
                Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), 0);
                if (Chart1.Series["LDR1"].Points.Count == Limit)
                {
                    Chart1.Series["LDR1"].Points.RemoveAt(0);
                }
                Chart1.ChartAreas[0].AxisY.Maximum = 1100;

                Chart1.Series["LDR2"].Points.AddY(0);
                if (Chart1.Series["LDR2"].Points.Count == Limit)
                {
                    Chart1.Series["LDR2"].Points.RemoveAt(0);
                }

                Chart1.Series["POTENTIO"].Points.AddY(0);
                if (Chart1.Series["POTENTIO"].Points.Count == Limit)
                {
                    Chart1.Series["POTENTIO"].Points.RemoveAt(0);
                }
            }
            DataGridView1.Rows.Clear();
        }

        private void ButtonClear_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i <= 30; i++)
            {
                Chart1.Series["LDR1"].Points.AddXY(DateTime.Now.ToLongTimeString(), 0);
                if (Chart1.Series["LDR1"].Points.Count == Limit)
                {
                    Chart1.Series["LDR1"].Points.RemoveAt(0);
                }
                Chart1.ChartAreas[0].AxisY.Maximum = 1100;

                Chart1.Series["LDR2"].Points.AddY(0);
                if (Chart1.Series["LDR2"].Points.Count == Limit)
                {
                    Chart1.Series["LDR2"].Points.RemoveAt(0);
                }

                Chart1.Series["POTENTIO"].Points.AddY(0);
                if (Chart1.Series["POTENTIO"].Points.Count == Limit)
                {
                    Chart1.Series["POTENTIO"].Points.RemoveAt(0);
                }
            }
            DataGridView1.Rows.Clear();
        }
        private void Datorecibido(object sender, SerialDataReceivedEventArgs e)
        {
            AccesoInterrupcion(serialPort1.ReadExisting());

        }
        private void botonenviar_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.DiscardOutBuffer();
                // strBufferOut = textenviar.Text; textbox con el nombre textenviar para visualizar y digitar valor enviado del tx rx
                strBufferOut = textenviado.Text;
                serialPort1.Write(strBufferOut);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message.ToString());
            }
        }

        private void datorecibido(object sender, SerialDataReceivedEventArgs e)
        {
            AccesoInterrupcion(serialPort1.ReadExisting());
        }
    }
}
