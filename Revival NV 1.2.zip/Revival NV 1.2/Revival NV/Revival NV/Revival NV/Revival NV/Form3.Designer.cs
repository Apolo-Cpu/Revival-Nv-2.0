﻿namespace Revival_NV
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PictureBoxConnectionInd = new System.Windows.Forms.PictureBox();
            this.LabelStatus = new System.Windows.Forms.Label();
            this.ButtonDisconnect = new System.Windows.Forms.Button();
            this.ButtonConnect = new System.Windows.Forms.Button();
            this.ComboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ComboBoxPort = new System.Windows.Forms.ComboBox();
            this.ButtonScanPort = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.botonenviar = new System.Windows.Forms.Button();
            this.textrecibido = new System.Windows.Forms.TextBox();
            this.textenviado = new System.Windows.Forms.TextBox();
            this.LabelPOT = new System.Windows.Forms.Label();
            this.LabelLDR2 = new System.Windows.Forms.Label();
            this.LabelLDR1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.PictureBoxRecordInd = new System.Windows.Forms.PictureBox();
            this.ButtonClear = new System.Windows.Forms.Button();
            this.ButtonStopRecording = new System.Windows.Forms.Button();
            this.ButtonStartRecording = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.ButtonSaveToExcel = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LDR1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LDR2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POTENTIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DATE_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxConnectionInd)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxRecordInd)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox1.Controls.Add(this.PictureBoxConnectionInd);
            this.groupBox1.Controls.Add(this.LabelStatus);
            this.groupBox1.Controls.Add(this.ButtonDisconnect);
            this.groupBox1.Controls.Add(this.ButtonConnect);
            this.groupBox1.Controls.Add(this.ComboBoxBaudRate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ComboBoxPort);
            this.groupBox1.Controls.Add(this.ButtonScanPort);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(409, 126);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Conexion";
            // 
            // PictureBoxConnectionInd
            // 
            this.PictureBoxConnectionInd.Image = global::Revival_NV.Properties.Resources.Rojo;
            this.PictureBoxConnectionInd.Location = new System.Drawing.Point(390, 0);
            this.PictureBoxConnectionInd.Name = "PictureBoxConnectionInd";
            this.PictureBoxConnectionInd.Size = new System.Drawing.Size(13, 13);
            this.PictureBoxConnectionInd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBoxConnectionInd.TabIndex = 10;
            this.PictureBoxConnectionInd.TabStop = false;
            // 
            // LabelStatus
            // 
            this.LabelStatus.AutoSize = true;
            this.LabelStatus.Location = new System.Drawing.Point(261, 0);
            this.LabelStatus.Name = "LabelStatus";
            this.LabelStatus.Size = new System.Drawing.Size(116, 13);
            this.LabelStatus.TabIndex = 16;
            this.LabelStatus.Text = "Estado: Desconectado";
            // 
            // ButtonDisconnect
            // 
            this.ButtonDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonDisconnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonDisconnect.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonDisconnect.Location = new System.Drawing.Point(203, 80);
            this.ButtonDisconnect.Name = "ButtonDisconnect";
            this.ButtonDisconnect.Size = new System.Drawing.Size(188, 28);
            this.ButtonDisconnect.TabIndex = 15;
            this.ButtonDisconnect.Text = "Desonectar";
            this.ButtonDisconnect.UseVisualStyleBackColor = false;
            this.ButtonDisconnect.Click += new System.EventHandler(this.ButtonDisconnect_Click);
            // 
            // ButtonConnect
            // 
            this.ButtonConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonConnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonConnect.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonConnect.Location = new System.Drawing.Point(9, 80);
            this.ButtonConnect.Name = "ButtonConnect";
            this.ButtonConnect.Size = new System.Drawing.Size(188, 28);
            this.ButtonConnect.TabIndex = 14;
            this.ButtonConnect.Text = "Conectar";
            this.ButtonConnect.UseVisualStyleBackColor = false;
            this.ButtonConnect.Click += new System.EventHandler(this.ButtonConnect_Click);
            // 
            // ComboBoxBaudRate
            // 
            this.ComboBoxBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxBaudRate.FormattingEnabled = true;
            this.ComboBoxBaudRate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.ComboBoxBaudRate.Location = new System.Drawing.Point(264, 40);
            this.ComboBoxBaudRate.Name = "ComboBoxBaudRate";
            this.ComboBoxBaudRate.Size = new System.Drawing.Size(127, 21);
            this.ComboBoxBaudRate.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(213, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Baudios";
            // 
            // ComboBoxPort
            // 
            this.ComboBoxPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxPort.FormattingEnabled = true;
            this.ComboBoxPort.ImeMode = System.Windows.Forms.ImeMode.On;
            this.ComboBoxPort.Location = new System.Drawing.Point(86, 40);
            this.ComboBoxPort.Name = "ComboBoxPort";
            this.ComboBoxPort.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxPort.TabIndex = 11;
            // 
            // ButtonScanPort
            // 
            this.ButtonScanPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonScanPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonScanPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonScanPort.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonScanPort.Location = new System.Drawing.Point(9, 35);
            this.ButtonScanPort.Name = "ButtonScanPort";
            this.ButtonScanPort.Size = new System.Drawing.Size(71, 28);
            this.ButtonScanPort.TabIndex = 10;
            this.ButtonScanPort.Text = "Scan Port";
            this.ButtonScanPort.UseVisualStyleBackColor = false;
            this.ButtonScanPort.Click += new System.EventHandler(this.ButtonScanPort_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox2.Controls.Add(this.botonenviar);
            this.groupBox2.Controls.Add(this.textrecibido);
            this.groupBox2.Controls.Add(this.textenviado);
            this.groupBox2.Controls.Add(this.LabelPOT);
            this.groupBox2.Controls.Add(this.LabelLDR2);
            this.groupBox2.Controls.Add(this.LabelLDR1);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Location = new System.Drawing.Point(427, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(242, 125);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Recepcion de Datos (Tiempo Real/Segundos)";
            // 
            // botonenviar
            // 
            this.botonenviar.BackColor = System.Drawing.Color.Navy;
            this.botonenviar.Location = new System.Drawing.Point(106, 83);
            this.botonenviar.Name = "botonenviar";
            this.botonenviar.Size = new System.Drawing.Size(113, 23);
            this.botonenviar.TabIndex = 17;
            this.botonenviar.Text = "enviar";
            this.botonenviar.UseVisualStyleBackColor = false;
            this.botonenviar.Click += new System.EventHandler(this.botonenviar_Click);
            // 
            // textrecibido
            // 
            this.textrecibido.Location = new System.Drawing.Point(102, 55);
            this.textrecibido.Name = "textrecibido";
            this.textrecibido.Size = new System.Drawing.Size(132, 20);
            this.textrecibido.TabIndex = 16;
            // 
            // textenviado
            // 
            this.textenviado.Location = new System.Drawing.Point(102, 25);
            this.textenviado.Name = "textenviado";
            this.textenviado.Size = new System.Drawing.Size(133, 20);
            this.textenviado.TabIndex = 15;
            // 
            // LabelPOT
            // 
            this.LabelPOT.AutoSize = true;
            this.LabelPOT.Location = new System.Drawing.Point(15, 82);
            this.LabelPOT.Name = "LabelPOT";
            this.LabelPOT.Size = new System.Drawing.Size(70, 13);
            this.LabelPOT.TabIndex = 14;
            this.LabelPOT.Text = "Esperando ...";
            // 
            // LabelLDR2
            // 
            this.LabelLDR2.AutoSize = true;
            this.LabelLDR2.Location = new System.Drawing.Point(15, 57);
            this.LabelLDR2.Name = "LabelLDR2";
            this.LabelLDR2.Size = new System.Drawing.Size(70, 13);
            this.LabelLDR2.TabIndex = 13;
            this.LabelLDR2.Text = "Esperando ...";
            // 
            // LabelLDR1
            // 
            this.LabelLDR1.AutoSize = true;
            this.LabelLDR1.Location = new System.Drawing.Point(15, 34);
            this.LabelLDR1.Name = "LabelLDR1";
            this.LabelLDR1.Size = new System.Drawing.Size(70, 13);
            this.LabelLDR1.TabIndex = 12;
            this.LabelLDR1.Text = "Esperando ...";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.PictureBoxRecordInd);
            this.groupBox3.Controls.Add(this.ButtonClear);
            this.groupBox3.Controls.Add(this.ButtonStopRecording);
            this.groupBox3.Controls.Add(this.ButtonStartRecording);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Location = new System.Drawing.Point(12, 144);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(409, 111);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Control";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(320, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Registrando";
            // 
            // PictureBoxRecordInd
            // 
            this.PictureBoxRecordInd.Image = global::Revival_NV.Properties.Resources.Rojo;
            this.PictureBoxRecordInd.Location = new System.Drawing.Point(390, 0);
            this.PictureBoxRecordInd.Name = "PictureBoxRecordInd";
            this.PictureBoxRecordInd.Size = new System.Drawing.Size(13, 13);
            this.PictureBoxRecordInd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBoxRecordInd.TabIndex = 18;
            this.PictureBoxRecordInd.TabStop = false;
            // 
            // ButtonClear
            // 
            this.ButtonClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonClear.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonClear.Location = new System.Drawing.Point(9, 59);
            this.ButtonClear.Name = "ButtonClear";
            this.ButtonClear.Size = new System.Drawing.Size(387, 46);
            this.ButtonClear.TabIndex = 13;
            this.ButtonClear.Text = "Limpiar";
            this.ButtonClear.UseVisualStyleBackColor = false;
            this.ButtonClear.Click += new System.EventHandler(this.ButtonClear_Click_1);
            // 
            // ButtonStopRecording
            // 
            this.ButtonStopRecording.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonStopRecording.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonStopRecording.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonStopRecording.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonStopRecording.Location = new System.Drawing.Point(203, 28);
            this.ButtonStopRecording.Name = "ButtonStopRecording";
            this.ButtonStopRecording.Size = new System.Drawing.Size(193, 25);
            this.ButtonStopRecording.TabIndex = 12;
            this.ButtonStopRecording.Text = "Detener";
            this.ButtonStopRecording.UseVisualStyleBackColor = false;
            this.ButtonStopRecording.Click += new System.EventHandler(this.ButtonStopRecording_Click);
            // 
            // ButtonStartRecording
            // 
            this.ButtonStartRecording.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonStartRecording.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonStartRecording.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonStartRecording.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonStartRecording.Location = new System.Drawing.Point(9, 28);
            this.ButtonStartRecording.Name = "ButtonStartRecording";
            this.ButtonStartRecording.Size = new System.Drawing.Size(188, 25);
            this.ButtonStartRecording.TabIndex = 11;
            this.ButtonStartRecording.Text = "Iniciar";
            this.ButtonStartRecording.UseVisualStyleBackColor = false;
            this.ButtonStartRecording.Click += new System.EventHandler(this.ButtonStartRecording_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox4.Controls.Add(this.progressBar1);
            this.groupBox4.Controls.Add(this.ButtonSaveToExcel);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Location = new System.Drawing.Point(427, 144);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(242, 111);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Salida";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(6, 95);
            this.progressBar1.Maximum = 10;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(230, 10);
            this.progressBar1.TabIndex = 16;
            this.progressBar1.Visible = false;
            // 
            // ButtonSaveToExcel
            // 
            this.ButtonSaveToExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonSaveToExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.ButtonSaveToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonSaveToExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSaveToExcel.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonSaveToExcel.Location = new System.Drawing.Point(6, 19);
            this.ButtonSaveToExcel.Name = "ButtonSaveToExcel";
            this.ButtonSaveToExcel.Size = new System.Drawing.Size(230, 86);
            this.ButtonSaveToExcel.TabIndex = 15;
            this.ButtonSaveToExcel.Text = "Exportar a Excel";
            this.ButtonSaveToExcel.UseVisualStyleBackColor = false;
            this.ButtonSaveToExcel.Click += new System.EventHandler(this.ButtonSaveToExcel_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox5.Controls.Add(this.DataGridView1);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox5.Location = new System.Drawing.Point(12, 261);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(657, 254);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Data Grid View (Tiempo Real/Segundos)";
            // 
            // DataGridView1
            // 
            this.DataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.No,
            this.LDR1,
            this.LDR2,
            this.TIME,
            this.POTENTIO,
            this.DATE_});
            this.DataGridView1.Location = new System.Drawing.Point(6, 19);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.Size = new System.Drawing.Size(645, 229);
            this.DataGridView1.TabIndex = 0;
            // 
            // No
            // 
            this.No.FillWeight = 76.14214F;
            this.No.HeaderText = "No";
            this.No.Name = "No";
            // 
            // LDR1
            // 
            this.LDR1.FillWeight = 104.7716F;
            this.LDR1.HeaderText = "LDR1";
            this.LDR1.Name = "LDR1";
            // 
            // LDR2
            // 
            this.LDR2.FillWeight = 104.7716F;
            this.LDR2.HeaderText = "LDR2";
            this.LDR2.Name = "LDR2";
            // 
            // TIME
            // 
            this.TIME.FillWeight = 104.7716F;
            this.TIME.HeaderText = "TIME";
            this.TIME.Name = "TIME";
            // 
            // POTENTIO
            // 
            this.POTENTIO.HeaderText = "POTENTIO";
            this.POTENTIO.Name = "POTENTIO";
            // 
            // DATE_
            // 
            this.DATE_.FillWeight = 104.7716F;
            this.DATE_.HeaderText = "DATE";
            this.DATE_.Name = "DATE_";
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Controls.Add(this.Chart1);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox6.Location = new System.Drawing.Point(675, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(602, 502);
            this.groupBox6.TabIndex = 15;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Grafica";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(23)))), ((int)(((byte)(38)))));
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox7.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox7.Location = new System.Drawing.Point(579, 16);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(20, 483);
            this.groupBox7.TabIndex = 15;
            this.groupBox7.TabStop = false;
            // 
            // Chart1
            // 
            this.Chart1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            chartArea1.Name = "ChartArea1";
            this.Chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.Chart1.Legends.Add(legend1);
            this.Chart1.Location = new System.Drawing.Point(6, 19);
            this.Chart1.Name = "Chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "LDR1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Legend = "Legend1";
            series2.Name = "LDR2";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Legend = "Legend1";
            series3.Name = "POTENTIO";
            this.Chart1.Series.Add(series1);
            this.Chart1.Series.Add(series2);
            this.Chart1.Series.Add(series3);
            this.Chart1.Size = new System.Drawing.Size(602, 477);
            this.Chart1.TabIndex = 0;
            this.Chart1.Text = "Grafica de Datos Sensados";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.datorecibido);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(31)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(1295, 528);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxConnectionInd)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxRecordInd)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox ComboBoxPort;
        private System.Windows.Forms.Button ButtonScanPort;
        private System.Windows.Forms.Label LabelStatus;
        private System.Windows.Forms.Button ButtonDisconnect;
        private System.Windows.Forms.Button ButtonConnect;
        private System.Windows.Forms.ComboBox ComboBoxBaudRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox PictureBoxConnectionInd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label LabelPOT;
        private System.Windows.Forms.Label LabelLDR2;
        private System.Windows.Forms.Label LabelLDR1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox PictureBoxRecordInd;
        private System.Windows.Forms.Button ButtonClear;
        private System.Windows.Forms.Button ButtonStopRecording;
        private System.Windows.Forms.Button ButtonStartRecording;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button ButtonSaveToExcel;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView DataGridView1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart1;
        private System.Windows.Forms.DataGridViewTextBoxColumn No;
        private System.Windows.Forms.DataGridViewTextBoxColumn LDR1;
        private System.Windows.Forms.DataGridViewTextBoxColumn LDR2;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIME;
        private System.Windows.Forms.DataGridViewTextBoxColumn POTENTIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DATE_;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textrecibido;
        private System.Windows.Forms.TextBox textenviado;
        private System.Windows.Forms.Button botonenviar;
        private System.IO.Ports.SerialPort serialPort1;
    }
}