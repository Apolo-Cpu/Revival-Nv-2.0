﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revival_NV
{
    public partial class Login : Form
    {
        public string Usuario { get; set; }
        public string usuario { get; set; }

        public Login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private int error = 0;

        private void button3_Click(object sender, EventArgs e)
        {
            string usuario = TextoUsuario.Text;
            string contraseña = TextoContraseña.Text;
            string tipoUsuario = comboBox1.Text;

            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(contraseña) || string.IsNullOrWhiteSpace(tipoUsuario))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
            }
            else if ((usuario == "Rafael" && contraseña == "123" && tipoUsuario == "Administrador") ||
                (usuario == "Nelson" && contraseña == "123" && tipoUsuario == "Operador") ||
                (usuario == "Nelson" && contraseña == "123" && tipoUsuario == "Técnico de Mantenimiento"))
            {
                MessageBox.Show("Bienvenido, Ha accedido como " + usuario);
                this.Hide();

                // Crear una instancia del formulario Form2
                Cargando form2 = new Cargando();

                // Establecer la propiedad Usuario en Form2
                form2.Usuario = usuario;

                // Mostrar el formulario Form2
                form2.ShowDialog();
            }
            else
            {
                error++;

                if (error >= 3)
                {
                    MessageBox.Show("Ha excedido el número de intentos permitidos.\nEl aplicativo se cerrará.");
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Usuario o Contraseña erroneos.\nIntento #" + error);

                    TextoUsuario.Clear();
                    TextoContraseña.Clear();
                }
            }
        }


        private void Test_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Cargando j = new Cargando();
            j.ShowDialog();
        }


    }
}
