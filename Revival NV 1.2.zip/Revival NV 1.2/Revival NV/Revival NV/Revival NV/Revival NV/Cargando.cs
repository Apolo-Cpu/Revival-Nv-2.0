﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revival_NV
{
    public partial class Cargando : Form
    {
        public string Usuario { get; set; }
        public string usuario { get; set; }
        public Cargando()
        {
            InitializeComponent();
        }



        //  mensajes
        private string[] messages = {
        "     Cargando datos del sistema",
        "   Verificando conexiones de red",
        " Preparando interfaz de usuario",
        "    Estableciendo comunicación ",
        "   Generando mapas de navegación",
        "          Calibrando sensores",
        "       Optimizando rendimiento",
        "     Inicializando componentes",
        "  Comunicándose con el servidor",
        "            Compilando shaders"
};

        private void timer1_Tick(object sender, EventArgs e)
        {
            // Incrementar el ancho de la barra de progreso
            metroProgressBar1.Width += 1;

            // Calcular el porcentaje de progreso
            int progressPercentage = (metroProgressBar1.Width * 100) / 700;

            // Calcular el índice basado en el porcentaje de progreso
            int messageIndex = (progressPercentage / 10) - 1;

            // Asegurarse de que el índice esté dentro del rango válido
            if (messageIndex >= 0 && messageIndex < messages.Length)
            {
                // Cambiar el mensaje en el Label
                label2.Text = messages[messageIndex];
            }

            // Control de la barra de progreso en función de su ancho
            if (metroProgressBar1.Width >= 620 && metroProgressBar1.Width <= 670)
            {
                System.Threading.Thread.Sleep(100);
            }
            else if (metroProgressBar1.Width >= 670)
            {
                // Detener el temporizador
                timer1.Stop();

                // Redimensionar la barra de progreso
                metroProgressBar1.Width = 700;

                // Esperar
                System.Threading.Thread.Sleep(100);

                // Ocultar el formulario actual y abrir el Form2
                this.Hide();
                Form2 j = new Form2();
                j.Usuario = usuario;
                j.FormClosed += (s, args) => this.Close(); // Cierra este formulario cuando Form2 se cierre
                j.ShowDialog();
            }
        }

        private void Cargando_Load(object sender, EventArgs e)
        {

        }

    }
}


