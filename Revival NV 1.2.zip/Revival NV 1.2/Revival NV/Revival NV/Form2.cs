﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revival_NV
{
    public partial class Form2 : Form
    {
        public string Usuario { get; set; }
        public string usuario { get; set; }

        public Form2()
        {
            InitializeComponent();
            hideSubMenu();
            label2.Text = usuario; // Asignar el valor de la propiedad "usuario" al Texto del control label2
        }

        private void hideSubMenu() //Esconder al inicio los paneles
        {
            panelMediaSubMenu.Visible = false;
            panelPlaylistSubMenu.Visible = false;
            panelToolsSubMenu.Visible = false;
        }

        private void PaneLogo_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void showSubMenu(Panel subMenu) //Logica de Mostrar/ocultar
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Mostrar el nombre de usuario en el Label
            label2.Text = Usuario;
        }


        private void button1_Click(object sender, EventArgs e) //Primer Panel
        {
            showSubMenu(panelMediaSubMenu);
        }

        private void button5_Click(object sender, EventArgs e) //Segundo Panel
        {
            showSubMenu(panelPlaylistSubMenu);
        }

        private void button6_Click(object sender, EventArgs e) //Tercer panel
        {
            showSubMenu(panelToolsSubMenu);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new Form3());
            //accion o evento  por sub menu
            hideSubMenu();
            MessageBox.Show("Para una mejor interaccion favor usar el modo \n pantalla completa al usar esta opcion");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new Form5());
            //accion o evento  por sub menu
            hideSubMenu();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new Form4());
            //accion o evento  por sub menu
            hideSubMenu();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Error j = new Error(); // Cambiar una vez se programe la opcion
            j.ShowDialog();
            hideSubMenu();
        }

        private Form activeForm = null;
        private void openChildFormInPanel(Form childForm)   //Abrir paneles hijos en menu
        {
            if (activeForm != null)   //logica para que abra un formulario cerrando el anterior
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }


        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login j = new Login(); // Login
            j.Usuario = Usuario; // Pasar el nombre de usuario al formulario Login
            j.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Text = usuario;
        }
    }
}
