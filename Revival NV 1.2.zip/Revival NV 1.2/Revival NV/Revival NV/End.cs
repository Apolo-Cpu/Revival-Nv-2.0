﻿namespace Revival_NV
{
    internal class End
    {
    }
}