﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revival_NV
{
    public partial class PlantillaNv : Form
    {
        public PlantillaNv()
        {
            InitializeComponent();
        }

        private void Cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
            PlantillaNv A = new PlantillaNv();
            A.ShowDialog();
        }

        private void Maximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized; // Normalizar
            Maximizar.Visible = false;
            Restaurar.Visible = true;
        }

        private void Restaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal; // Normalizar
            Restaurar.Visible = false;
            Maximizar.Visible = true;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized; // Minimizar
        }

        private void Panel_Arriba_Paint(object sender, PaintEventArgs e)
        {

        }

        bool vai = false; // Mover Pantalla
        private void Panel_Arriba_MouseDown(object sender, MouseEventArgs e)
        {
            vai = true;
        }

        private void Panel_Arriba_MouseUp(object sender, MouseEventArgs e)
        {
            vai = false;
        }

        private void Panel_Arriba_MouseMove(object sender, MouseEventArgs e)
        {

            if (vai == true)
            {

                this.Location = Cursor.Position;

            }

        }

        private bool panelReducido = false;

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panelReducido = !panelReducido;
            Panel_Lateral_Izquierdo.Width = panelReducido ? 110 : 224;
        }

        private void btnUsuarios_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 j = new Form2();
            j.ShowDialog();
        }
    }
}
